package it.unipv.sfw.rentacar.model.veicolo.caratteristiche;

/*
 * Enumeration Cambio
 */

public enum Cambio {

	MANUALE,
	AUTOMATICO
	
}


