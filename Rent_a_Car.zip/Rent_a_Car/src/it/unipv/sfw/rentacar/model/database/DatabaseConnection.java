package it.unipv.sfw.rentacar.model.database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/*
 * Classe DatabaseConnection
 */

public class DatabaseConnection {
	

    // Metodo di connessione al DB
    
    public static Connection connessione() throws SQLException, FileNotFoundException, IOException {
    	
    	String dbDriver;
		String dbURL;
		String username;
		String password;

		dbDriver = "com.mysql.cj.jdbc.Driver";
		
    	try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver JDBC non trovato", e);
        }


        Properties props = new Properties();
        
        try (FileInputStream input = new FileInputStream("config.properties")) {
            props.load(input);
            dbURL = props.getProperty("DB_URL");
            username = props.getProperty("DB_USERNAME");
            password = props.getProperty("DB_PASSWORD");
    	
        return DriverManager.getConnection(dbURL, username, password);
        }
    
    }
    
    
    public static void chiusura(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static boolean connessioneAperta(DatabaseConnection conn) {
    	if (conn == null) {
			return false;
		}else
			return true;
    }
    
    public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {
       	DatabaseConnection.connessione();
	}
}
    
