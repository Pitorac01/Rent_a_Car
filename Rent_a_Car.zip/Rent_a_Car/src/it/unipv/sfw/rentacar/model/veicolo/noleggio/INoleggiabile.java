package it.unipv.sfw.rentacar.model.veicolo.noleggio;

/*
 * Interface Inoleggiabile
 */

public interface INoleggiabile {

	public boolean noleggiabile();
	
}
