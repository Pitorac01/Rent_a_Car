package it.unipv.sfw.rentacar.model.veicolo.caratteristiche;

/*
 * Enumeration Carburante
 */

public enum Carburante {

	BENZINA,
	GASOLIO,
	ELETTRICA,
	GPL
	
}
