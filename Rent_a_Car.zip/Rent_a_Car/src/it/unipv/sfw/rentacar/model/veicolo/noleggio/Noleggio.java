package it.unipv.sfw.rentacar.model.veicolo.noleggio;

/*
 * Enumeration Noleggio
 */

public enum Noleggio {

	DISPONIBILE,
	NOLEGGIATA
	
}
